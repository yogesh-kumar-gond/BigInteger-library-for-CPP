# BigInteger-library-for-CPP
Download all Three File(BigInteger.h, BigInteger.cpp, Test_file.cpp) in same directory

Run  this  g++ -o main Test_file.cpp BigInteger.cpp
